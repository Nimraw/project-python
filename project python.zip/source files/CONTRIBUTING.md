# Hail the contributors!
Eternal thanks to you, as _YOU_ make this project live and thrive!

*Contributing is easy, baby!*

You will find all of the details to get started [on the official documentation website](https://pyowm.readthedocs.io/)

## Quick guide on code contributions
If you're eager to start coding on PyOWM, please follow these steps:

  1. Fork the PyOWM repository
  2. On your fork, work on the **development branch** (_not the master branch!!!_) or on a **ad-hoc topic branch**. Don't forget to insert your name in the `CONTRIBUTORS.md` file!
  3. TEST YOUR CODE please! [Here's the gig](https://github.com/csparpa/pyowm/wiki/Notes-on-testing)
  4. Submit a [pull request](https://help.github.com/articles/about-pull-requests/)
