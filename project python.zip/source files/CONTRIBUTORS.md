Thanks to the contributors
==========================

Contributors will be shown in alphabetical order

Code
----
  * [ahertz](https://github.com/ahertz)
  * [alechewitt](https://github.com/alechewitt)
  * [camponez](https://github.com/camponez)
  * [Darumin](https://github.com/Darumin)
  * [davidpirogov](https://github.com/davidpirogov)
  * [dev-iks](https://github.com/dev-iks)
  * [dphildebrandt](https://github.com/dphildebrandt)
  * [dstmar](https://github.com/dstmar)
  * [edenhaus](https://github.com/edenhaus)
  * [eumiro](https://github.com/eumiro)
  * [ggstuart](https://github.com/ggstuart)
  * [irahorecka](https://github.com/irahorecka)
  * [jwmelvin](https://github.com/jwmelvin)
  * [lardconcepts](https://github.com/lardconcepts)
  * [liato](https://github.com/liato)
  * [LukasBoersma](https://github.com/LukasBoersma)
  * [MatthiasLohr](https://github.com/MatthiasLohr)  
  * [Misiu](https://github.com/Misiu)
  * [Noid](https://github.com/n0id)
  * [titilambert](https://github.com/titilambert)
  * [Tobiaqs](https://github.com/Tobiaqs)
  * [txemi](https://github.com/txemi)
  * [Wesley-Vos](https://github.com/Wesley-Vos)

Docs
----
  * [Crozzers](https://github.com/Crozzers)
  * [EJEP](https://github.com/EJEP)
  * [Franzqat](https://github.com/franzqat)
  * [Harmon758](https://github.com/Harmon758)
  * [joe-meyer](https://github.com/joe-meyer)

Testing
-------
  * [Ankur](https://github.com/Ankuraxz)
  * [Samuel Yap](https://github.com/samuelyap)
  * [Patrick Casbon](https://github.com/patcas)
  * [Tamas Magyar](https://github.com/tamasmagyar)

Packaging and Distribution
--------------------------
  * [Crozzers](https://github.com/Crozzers)
  * [Diapente](https://github.com/Diapente)
  * [onkelbeh](https://github.com/onkelbeh)
  * [Simone-Zabberoni](https://github.com/Simone-Zabberoni)

Wiki
----
  * [lardconcepts](https://github.com/lardconcepts)
  * [richarddunks](https://github.com/richarddunks)
  * [solumos](https://github.com/solumos)

Logo
----
  * [marlinmm](https://github.com/marlinmm)
