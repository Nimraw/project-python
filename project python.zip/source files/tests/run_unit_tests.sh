#!/usr/bin/env bash

set -o errexit

cd ..
tox
