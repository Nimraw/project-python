# City ID Registry usage examples

Using city IDS instead of toponyms or geographic coordinates is the preferred way of querying the OWM weather API
 
You can obtain the city ID for your toponyms/geocoords of interest via the `City ID Registry`.

Please refer to the `Code Recipes` page, section: `Identifying cities and places via city IDs`, to get info about it