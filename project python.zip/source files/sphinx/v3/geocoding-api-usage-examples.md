# Geocoding API usage examples

The OWM Weather API gives you the possibility to perform direct and reverse geocoding:
  - DIRECT GEOCODING: from toponym to geocoords
  - REVERSE GEOCODING: from geocoords to toponyms


Please refer to the `Code Recipes` page, sections: `Direct/reverse geocoding`
