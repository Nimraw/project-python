# Weather API usage examples

The OWM Weather API gives you data about currently observed and forecast weather data upon cities in the world.

Please refer to the `Code Recipes` page, sections: `Weather data`, `Weather forecasts` and `Meteostation historic measurements` to know more.
